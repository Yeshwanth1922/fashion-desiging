# Stitch - Fashion Social Platform

A premium social platform for discovering and sharing Kurti & Blouse fashion designs. Built with modern web technologies and featuring a fully interactive, responsive UI.

## 🌟 Features

### Interactive UI Components
- **Like & Save Functionality**: Click heart icons to like designs
- **Follow/Unfollow Designers**: Interactive follow buttons with state management
- **Category Filters**: Filter designs by category (Silk, Cotton, Wedding, etc.)
- **Search Functionality**: Search for designs and hashtags
- **Form Validation**: Real-time validation for profile setup
- **Tab Navigation**: Switch between Posts, Saved, and Archive sections
- **Story Interactions**: View designer stories and updates

### Design Features
- **Responsive Layout**: Works perfectly on desktop, tablet, and mobile devices
- **Dark Mode Support**: Toggle between light and dark themes
- **Masonry Grid**: Pinterest-style layout for design discovery
- **Smooth Animations**: Fade-in effects and hover transitions
- **Glass Morphism**: Modern frosted glass effects
- **Custom Scrollbars**: Hidden scrollbars for cleaner look

### Pages Included

1. **Index/Landing Page** (`index.html`)
   - Central hub with navigation to all pages
   - Feature highlights
   - Responsive card grid

2. **Explore & Trending Designs** (`explore_&_trending_designs/code.html`)
   - Browse trending fashion designs
   - Designer spotlight section
   - Filter by categories
   - Interactive like buttons
   - Load more functionality

3. **Fashion Discovery Feed** (`fashion_discovery_feed/code.html`)
   - Instagram-style stories section
   - Masonry grid feed
   - Like, comment, and bookmark features
   - Category badges
   - Bottom navigation

4. **Premium Landing Page** (`premium_landing_page/code.html`)
   - Hero section with CTA buttons
   - Curated design collections
   - Newsletter signup
   - Designer application form
   - Full footer with links

5. **Profile Setup/Onboarding** (`profile_setup_onboarding/code.html`)
   - Profile image upload
   - Username validation (min 3 characters)
   - Bio with character counter (160 max)
   - Privacy toggle
   - Progress bar tracking completion
   - Form validation

6. **User Profile Dashboard** (`user_profile_dashboard/code.html`)
   - User profile with stats (Followers, Following, Posts)
   - Tab navigation (Posts, Saved, Archive)
   - Design grid with hover effects
   - Like and comment counts
   - Edit profile functionality

## 🚀 Getting Started

### Quick Start
1. Open `index.html` in any modern web browser
2. Navigate to different pages using the card links
3. Interact with buttons, forms, and UI elements

### No Installation Required
This is a pure HTML/CSS/JavaScript project using:
- Tailwind CSS (via CDN)
- Google Fonts (Plus Jakarta Sans)
- Material Symbols Icons

## 💡 Interactive Features Guide

### Like/Favorite Buttons
- Click heart icons on designs to like/unlike
- Button changes color from white to red when liked
- Icon fills in when active

### Follow Buttons
- Click "Follow" to become "Following"
- Click "Following" to unfollow
- Button styling updates automatically

### Category Filters
- Click category buttons to filter content
- Active category highlighted in primary color
- Only one category active at a time

### Search Functionality
- Type in search boxes and press Enter
- Displays search query in alert (can be connected to backend)

### Form Validation (Profile Setup)
- Username: Minimum 3 characters, alphanumeric only
- Bio: Maximum 160 characters with live counter
- Profile Image: Click to upload (displays instantly)
- Progress bar updates based on completion

### Tab Navigation (Profile Dashboard)
- Click tabs to switch between sections
- Active tab shows underline indicator
- Smooth transitions between views

### Load More
- Click "Load More" buttons to fetch additional content
- Shows loading state during fetch

### Theme Toggle
- Click moon/sun icon to switch themes
- Preference saved in localStorage
- Applies across entire site

## 🎨 Customization

### Colors
Main colors are defined in Tailwind config:
- Primary: `#ee2b3b` (Rose Red)
- Background Light: `#f8f6f6`
- Background Dark: `#221012`

To change colors, modify the `tailwind.config` in each HTML file's `<script>` tag.

### Fonts
Currently using:
- Display: Plus Jakarta Sans
- Icons: Material Symbols Outlined

Change fonts by updating the Google Fonts link in the `<head>` section.

## 📱 Responsive Breakpoints

- Mobile: < 640px (1 column masonry)
- Tablet: 640px - 1024px (2 column masonry)
- Desktop: > 1024px (3-4 column masonry)

## 🔧 Technical Details

### JavaScript Features
- Event listeners for all interactive elements
- Form validation with real-time feedback
- LocalStorage for theme preferences
- Intersection Observer for scroll animations
- Click handlers for likes, follows, and filters

### CSS Features
- Tailwind utility classes
- Custom animations and transitions
- Media queries for responsiveness
- CSS Grid and Flexbox layouts
- Backdrop blur effects

### Browser Support
- Chrome/Edge (latest)
- Firefox (latest)
- Safari (latest)
- Mobile browsers (iOS Safari, Chrome Mobile)

## 🎯 Use Cases

Perfect for:
- Fashion e-commerce platforms
- Social media for designers
- Portfolio websites
- Fashion discovery apps
- Design inspiration platforms

## 📝 Notes

- All images use Google's Aida public image service
- JavaScript interactions work without backend
- Can be easily integrated with REST APIs
- Forms ready for backend integration
- Material Icons load from CDN

## 🚀 Future Enhancements

Potential additions:
- Backend API integration
- User authentication
- Real-time notifications
- Image upload to server
- Social sharing features
- Comments system
- Messaging functionality
- Shopping cart
- Payment integration

## 📄 License

This is a UI template project. Feel free to use and modify for your projects.

## 🤝 Contributing

To contribute:
1. Test thoroughly in multiple browsers
2. Maintain responsive design
3. Follow existing code style
4. Ensure accessibility standards

## 📧 Support

For questions or issues:
- Check browser console for errors
- Ensure JavaScript is enabled
- Verify internet connection (for CDN resources)

---

**Made with ❤️ for fashion enthusiasts**

Enjoy exploring the Stitch platform! 🎨✨
